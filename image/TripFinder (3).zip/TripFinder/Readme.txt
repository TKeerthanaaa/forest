Bolier Plate which is gonna use for all the pojects from here this all files and contents are important to use every time so we predifined them now for preventing us from rework.
